### 1.0.0 / 10-02-2014###

**Development**

* Created project folder structure
* Created README.md and CHANGELOG.md files
* Basic HTML template for dev and demo
* CSS styling of template
* Include jQuery UI
* jQuery plugin boilerplate
* Set default options - direction, speed,scrollstart, slideback
* Window scroll and slide in/out functionality